function [ f1 ] = bsf1_R( bsStates,bsParams )
   f1 = 0;
end