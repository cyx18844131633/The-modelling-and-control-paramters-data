function [ f2 ] = bsf2_P( bsStates,bsParams )
   f2 = 0;
end