function [ f1 ] = bsf1_P( bsStates,bsParams )
   f1 = 0;
end