function [ g1 ] = bsg1_P( bsStates,bsParams )
   g1 = eye(3);
end